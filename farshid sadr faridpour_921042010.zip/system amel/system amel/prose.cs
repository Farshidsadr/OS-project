﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace system_amel
{
    public class prose
    {
        public int PID { get; set; }
        public string ProcessName { get; set; }
        public string State { get; set; }
        public double TotalTime { get; set; }
        public int Block_time { get; set; }
        public int Suspend_time { get; set; }
        static int ID = 1000;
        

        public prose(string pn,string state,double totaltime)
        {
            PID = ID++;
            ProcessName = pn;
            State = state;
            TotalTime = totaltime;
            Suspend_time = 0;
            Block_time = 0;
        }
    }

}
