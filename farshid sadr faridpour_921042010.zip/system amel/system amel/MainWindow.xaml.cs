﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Threading;
using System.IO;

namespace system_amel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //baraye har no-e proce yek list dar nazar gereftam,baraye rahatie kar ba listbox-ha
        //va bahine budane barname

        List<prose> New = new List<prose>();
        List<prose> Ready = new List<prose>(10);
        List<prose> Blocked = new List<prose>();
        List<prose> Suspend = new List<prose>();
        List<prose> Finished = new List<prose>();
        List<prose> Running = new List<prose>();

        public MainWindow()
        {
            InitializeComponent();
            TextBoxPname.Focus();
            //yek timer dorost kardam ke har 1 sanie be tabe-e TimerOnTick beravad
            DispatcherTimer timer=new DispatcherTimer();
            timer.Interval =new TimeSpan(0,0,1);

            timer.Tick += TimerOnTick;
            timer.Start();
        }


        bool ready = true;
        private void TimerOnTick(object sender, EventArgs eventArgs)
        {
            //dar har 1 sanie totaltime ke zamane kolle ejraye barname ast ra,baraye hameye proce ha be joz new, 1 vahed ziad mikonam
            foreach (var VARIABLE in Ready)
            {
                VARIABLE.TotalTime++;
            }
            foreach (var VARIABLE in Running)
            {
                VARIABLE.TotalTime++;
            }

            // baraye block alave bar in ke total time ra ziad mikonam,io_time ra yek vahed kam mikonam
            // ta agar io_time sefr shod be liste ready ha beravad
            // blockitemtimezero ra baraye in dar nazar gereftam ke agar io_time yek ya chand proceye block sefr shod
            // be dakhele if beravam va liste procehaye block ra update konam
            bool blockitemtimezero = false;
            foreach (var VARIABLE in Blocked)
            {
                VARIABLE.TotalTime++;
                VARIABLE.Block_time--;
                if (VARIABLE.Block_time == 0)
                {
                    if (Ready.Count < 10 && VARIABLE.Suspend_time<=0)
                    {
                        VARIABLE.State = "Ready";
                        Ready.Add(VARIABLE);
                    }
                    else
                    {
                        VARIABLE.State = "Suspend";
                        Suspend.Add(VARIABLE);
                    }
                    blockitemtimezero = true;
                }
            }
            if (blockitemtimezero)
            {
                List<prose> tempblock = new List<prose>();
                foreach (var VARIABLE in Blocked)
                {
                    if (VARIABLE.State == "Blocked")
                        tempblock.Add(VARIABLE);
                }
                Blocked = tempblock;
                blockitemtimezero = false;
            }

            // baraye suspend alave bar in ke total time ra ziad mikonam,io_time ra yek vahed kam mikonam
            // ta agar io_time 2 shod be liste block ha beravad va baghieye marahel ra tey konad
            // bool suspendtime ra baraye in dar nazar gereftam ke agar io_time yek ya chand proceye suspend 2 shod
            // be dakhele if beravam va liste procehaye suspend ra update konam(chon dakhele foreach nemitavanam ozvi ra hazf konam
            // ba yek if control kardam hazf kardane ozvhaii ke suspend budand va mikhaham az liste suspend hazf konam

            bool suspendtime = false;
            //suspend ha ra sort mikonam ta proceii ke zamane ziadist dar suspend ast be ready beravad
            Suspend.Sort(delegate(prose p1, prose p2) { return p1.Suspend_time.CompareTo(p2.Suspend_time); });
            foreach (var VARIABLE in Suspend)
            {
                VARIABLE.TotalTime++;
                VARIABLE.Suspend_time--;
                if (VARIABLE.Suspend_time <= 0)
                {
                    if (Ready.Count < 10)

                    {
                        VARIABLE.State = "Ready";
                        Ready.Add(VARIABLE);
                    }
                    suspendtime = true;
                }
            }
            if (suspendtime)
            {
                List<prose> tempsuspend=new List<prose>();
                foreach (var VARIABLE in Suspend)
                {
                    if(VARIABLE.State=="Suspend")
                        tempsuspend.Add(VARIABLE);
                }
                Suspend = tempsuspend;
                suspendtime = false;
            }

            //agar dar running ozvi bud ye r random tolid kardam beyne 0va4 agar randome tolid shode 2 bud interupte IO etefag oftade
            
            if (Running.Count > 0)
            {
                Random r = new Random();
                int rand = r.Next(0, 4);
                if (rand==2)
                {
                    //agar interupt etefag oftade bashad varede in if mishavim
                    //dar inja yek io_time random beyne 1ta5 entekhab mikonam
                    //agar bishtar az 2sanie bud blocktime ke 2 sanie mishavad,va baghimandeye io_time baraye suspendtime mishavad
                    //agar kamtar az 3 bud block_time=io_time mishavad va be andazeye io_time dar block mimanad
                    Random rt = new Random();
                    int IO_time = r.Next(1, 5);

                    if (IO_time > 2)
                    {
                        Running[0].State = "Blocked";
                        Running[0].Block_time = 2;
                        Running[0].Suspend_time = IO_time - 2;
                        Blocked.Add(Running[0]);
                        Running.Clear();
                        if (Ready.Count > 0)
                        {
                            Ready[0].State = "Running";
                            Running.Add(Ready[0]);
                            Ready.RemoveAt(0);   
                        }
                    }
                    else
                    {
                        Running[0].State = "Blocked";
                        Running[0].Block_time = IO_time;
                        Running[0].Suspend_time = 0;
                        Blocked.Add(Running[0]);
                        Running.Clear();
                        if (Ready.Count > 0)
                        {
                            Ready[0].State = "Running";
                            Running.Add(Ready[0]);
                            Ready.RemoveAt(0);
                        }
                    }
                    //tabe-e refreshlistboxes ra dar har yek sanie call mikonam ta agar taghiri dar list ha bashad,listbox ha update shavad
                    refreshlistboxes();
                    //agar interupt etefag oftade bashad bade in k karhaye bala ra kardam return mikonam ta kar-haye ziri ra nakonad
                    return;
                }
                //in gesmat az code marbut be zamanist ke interupt etefag nayoftade
                //ke fagat dar in gesmat running ra be ready borde va proceye avale safe ready ra be running miavaram
                Running[0].State = "Ready";
                Ready.Add(Running[0]);
                Running.Clear();
                Ready[0].State = "Running";
                Running.Add(Ready[0]);
                Ready.RemoveAt(0);

            }
            else
                ready = true;
            //boolean ready baraye in ast ke yek dar mian amaliate marbut be bordane running be ready va bar-ax anjam shavad
            //masalan agar dar in sanie ready amaliate marbut be ready anjam shod
            //dar saniyeye badi amaliate marbut be running anjam shavad
            //chon harkodam az running va ready bayad har 1sanie avaz shavad

            //dar safe ready ozvi dashte bashim va booleane ready true bashad az ready ye ozv be running miavaram va running ra be ready mibaram
            if (Ready.Count > 0 && ready)
            {
                Ready[0].State = "Running";
                Running.Add(Ready[0]);
                Ready.RemoveAt(0);
                ready = false;
            }
            //agar safe ready tedade azayash kamtar az 10 bashad,yek ozv az NEW ke procehaii ast k ijad shode-and vali be ready nayamade-and hanuz ra,be ready miavarim
            if (Ready.Count < 10 && New.Count > 0)
            {
                Ready.Add(New[0]);
                New.RemoveAt(0);
            }
            ////tabe-e refreshlistboxes ra dar har yek sanie call mikonam ta agar taghiri dar list ha bashad,listbox ha update shavad
            refreshlistboxes();
        }


        private void ButtonADD_Click(object sender, RoutedEventArgs e)
        {
            //vagti buttone ADD ra mizanim yek proce dorost mikonim,ke felan state an NEW ast
            prose p=new prose(TextBoxPname.Text,"New",0);
            New.Add(p);
            TextBoxPname.Text = "";
            ListBoxNew.ItemsSource = New;
            ListBoxNew.Items.Refresh();

            //agar kamtar az 10 ozv da ready dashtim in proceii ke ijad kardim va NEW ast ra be ready mibarim
            if (Ready.Count < 10)
            {
                p.State = "Ready";
                Ready.Add(p);
                New.Remove(p);
            }
            ListBoxReady.ItemsSource = Ready;
            ListBoxReady.Items.Refresh();
        }


        //vagti end ro zad proce ro az tamami list ha hazf mikonam va an ra be liste Finished ezafe mikonam
        private void ButtonEND_Click(object sender, RoutedEventArgs e)
        {
            prose p = null;
            string text = "";
            foreach (var VARIABLE in New)
            {
                if (VARIABLE.PID.ToString() == TextBoxPID.Text)
                {
                    New.Remove(VARIABLE);
                    p = VARIABLE;
                    break;
                }
            }
            foreach (var VARIABLE in Ready)
            {
                if (VARIABLE.PID.ToString() == TextBoxPID.Text)
                {
                    Ready.Remove(VARIABLE);
                    p = VARIABLE;
                    break;
                }
            }
            foreach (var VARIABLE in Blocked)
            {
                if (VARIABLE.PID.ToString() == TextBoxPID.Text)
                {
                    Blocked.Remove(VARIABLE);
                    p = VARIABLE;
                    break;
                }
            }
            foreach (var VARIABLE in Suspend)
            {
                if (VARIABLE.PID.ToString() == TextBoxPID.Text)
                {
                    Suspend.Remove(VARIABLE);
                    p = VARIABLE;
                    break;
                }
            }
            foreach (var VARIABLE in Running)
            {
                if (VARIABLE.PID.ToString() == TextBoxPID.Text)
                {
                    Running.Remove(VARIABLE);
                    p = VARIABLE;
                    break;
                }
            }
            //dar inja agar proceii ke mikhahim exit konim,agar peyda shode bashad state an ra Finished mikonam va dar file minevisam natijeye an ra
            if (p != null)
            {
                p.State = "Finished";
                text = p.PID.ToString() + "\t\t" + p.ProcessName + "\t\t" + p.TotalTime +
                                      " (seconds)\r\n";
                File.AppendAllText(Environment.CurrentDirectory + "\\log.txt", text);
                Finished.Add(p);
                TextBoxPID.Text = "";
                refreshlistboxes();
            }
        }

        //tabe-e refreshlistboxes ham har vagt seda shavad listbox ha ra ba tavajoh be list proce-ha reftresh mikonad
        private void refreshlistboxes()
        {
            ListBoxNew.ItemsSource = New;
            ListBoxNew.Items.Refresh();

            ListBoxReady.ItemsSource = Ready;
            ListBoxReady.Items.Refresh();

            ListBoxblocked.ItemsSource = Blocked;
            ListBoxblocked.Items.Refresh();

            ListBoxfinished.ItemsSource = Finished;
            ListBoxfinished.Items.Refresh();

            ListBoxrunning.ItemsSource = Running;
            ListBoxrunning.Items.Refresh();

            ListBoxsuspend.ItemsSource = Suspend;
            ListBoxsuspend.Items.Refresh();
        }
        
        private void TextBoxPname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                ButtonADD_Click(null, null);
        }

        private void TextBoxPID_OnPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }


        private void TextBoxPID_OnKeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key==Key.Enter)
                ButtonEND_Click(null,null);
        }


        private void MainWindow_OnClosing(object sender, CancelEventArgs e)
        {
            string text ="\n----------------------" + DateTime.Now.ToLongDateString() + "-------------------------\n";
            File.AppendAllText(Environment.CurrentDirectory + "\\log.txt", text);
        }

        //dar in tavabe-e zir,agar dar listbox haye marbute ozvi ra entekhab konim,dar listboxe information,etelaate proceii ke entekhab kardim nemayesh dade mishavad
        private void ListBoxNew_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Binding binding = new Binding();
            binding.ElementName = "ListBoxNew";
            binding.Path = new PropertyPath("SelectedItem");
            binding.Mode = BindingMode.TwoWay;
            ListBoxPinfo.SetBinding(DataContextProperty, binding);
        }

        private void ListBoxReady_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxfinished.UnselectAll();
            ListBoxNew.UnselectAll();
            ListBoxblocked.UnselectAll();
            ListBoxrunning.UnselectAll();
            ListBoxsuspend.UnselectAll();

            Binding binding = new Binding();
            binding.ElementName = "ListBoxReady";
            binding.Path = new PropertyPath("SelectedItem");
            binding.Mode = BindingMode.TwoWay;
            ListBoxPinfo.SetBinding(DataContextProperty, binding);
        }

        private void ListBoxsuspend_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxfinished.UnselectAll();
            ListBoxNew.UnselectAll();
            ListBoxblocked.UnselectAll();
            ListBoxrunning.UnselectAll();
            ListBoxReady.UnselectAll();

            Binding binding = new Binding();
            binding.ElementName = "ListBoxsuspend";
            binding.Path = new PropertyPath("SelectedItem");
            binding.Mode = BindingMode.TwoWay;
            ListBoxPinfo.SetBinding(DataContextProperty, binding);
        }

        private void ListBoxrunning_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxfinished.UnselectAll();
            ListBoxNew.UnselectAll();
            ListBoxblocked.UnselectAll();
            ListBoxReady.UnselectAll();
            ListBoxsuspend.UnselectAll();

            Binding binding = new Binding();
            binding.ElementName = "ListBoxrunning";
            binding.Path = new PropertyPath("SelectedItem");
            binding.Mode = BindingMode.TwoWay;
            ListBoxPinfo.SetBinding(DataContextProperty, binding);
        }

        private void ListBoxblocked_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxfinished.UnselectAll();
            ListBoxNew.UnselectAll();
            ListBoxReady.UnselectAll();
            ListBoxrunning.UnselectAll();
            ListBoxsuspend.UnselectAll();

            Binding binding = new Binding();
            binding.ElementName = "ListBoxblocked";
            binding.Path = new PropertyPath("SelectedItem");
            binding.Mode = BindingMode.TwoWay;
            ListBoxPinfo.SetBinding(DataContextProperty, binding);
        }

        private void ListBoxfinished_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxReady.UnselectAll();
            ListBoxNew.UnselectAll();
            ListBoxblocked.UnselectAll();
            ListBoxrunning.UnselectAll();
            ListBoxsuspend.UnselectAll();

            Binding binding = new Binding();
            binding.ElementName = "ListBoxfinished";
            binding.Path = new PropertyPath("SelectedItem");
            binding.Mode = BindingMode.TwoWay;
            ListBoxPinfo.SetBinding(DataContextProperty, binding);
        }

    }
}
